#include <wdf.h>
#include "DeviceAdd.h" // Подключаем заголовочный файл с прототипом функции EvtDeviceAdd

// Объявляем функцию EvtDeviceAdd, которая будет определена в другом месте
NTSTATUS EvtDeviceAdd(
    _In_ WDFDRIVER       Driver,
    _Inout_ PWDFDEVICE_INIT DeviceInit
);

// Точка входа драйвера
NTSTATUS DriverEntry(
    _In_ PDRIVER_OBJECT  DriverObject,
    _In_ PUNICODE_STRING RegistryPath
)
{
    WDF_DRIVER_CONFIG config;
    NTSTATUS status = STATUS_SUCCESS;

    // Инициализируем библиотеку KMDF для этого драйвера
    WDF_DRIVER_CONFIG_INIT(&config,
                           EvtDeviceAdd // Устанавливаем нашу функцию для обработки события добавления нового устройства
    );

    // Устанавливаем версию UMDF, которую мы будем использовать
    config.DriverInitFlags = WdfDriverInitNonPnpDriver;
    config.EvtDriverUnload = NULL; // Если необходимо обработать выгрузку драйвера, можно указать функцию здесь

    // Создаем драйвер с нашими настройками
    status = WdfDriverCreate(DriverObject,
                             RegistryPath,
                             WDF_NO_OBJECT_ATTRIBUTES,
                             &config,
                             WDF_NO_HANDLE // Этот параметр не используется с UMDF, так что просто передаем WDF_NO_HANDLE
    );

    if (!NT_SUCCESS(status)) {
        // Если создание драйвера не удалось, выводим сообщение об ошибке
        KdPrint(("KeyboardAsMouseDriver: WdfDriverCreate failed with status code %!STATUS!\n", status));
    }

    return status;
}
