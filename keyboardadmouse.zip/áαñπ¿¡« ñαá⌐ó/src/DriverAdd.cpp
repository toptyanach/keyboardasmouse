#include <wdf.h>
#include "DeviceAdd.h" // Предполагается, что этот заголовочный файл содержит прототип функции EvtDeviceAdd

NTSTATUS EvtDeviceAdd(
    _In_ WDFDRIVER Driver,
    _Inout_ PWDFDEVICE_INIT DeviceInit
)
{
    NTSTATUS status;
    WDFDEVICE device;
    WDF_OBJECT_ATTRIBUTES deviceAttributes;
    WDFDEVICE_INIT* pInit = DeviceInit;
    DECLARE_CONST_UNICODE_STRING(deviceName, L"\\Device\\YourVirtualMouseDevice");

    UNREFERENCED_PARAMETER(Driver);

    // Установить тип устройства
    WdfDeviceInitSetDeviceType(pInit, FILE_DEVICE_UNKNOWN);

    // Инициализация атрибутов устройства
    WDF_OBJECT_ATTRIBUTES_INIT(&deviceAttributes);
    deviceAttributes.SynchronizationScope = WdfSynchronizationScopeNone;

    // Создание устройства
    status = WdfDeviceCreate(&pInit, &deviceAttributes, &device);
    if (!NT_SUCCESS(status)) {
        KdPrint(("Failed to create device (Status code: %!STATUS!)\n", status));
        return status;
    }

    // Создание символической ссылки для устройства, чтобы приложения могли с ним взаимодействовать
    status = WdfDeviceCreateSymbolicLink(device, &deviceName);
    if (!NT_SUCCESS(status)) {
        KdPrint(("Failed to create symbolic link for device (Status code: %!STATUS!)\n", status));
        return status;
    }

    return STATUS_SUCCESS;
}
