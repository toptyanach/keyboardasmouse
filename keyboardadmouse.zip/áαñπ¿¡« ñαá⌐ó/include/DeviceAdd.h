#ifndef DEVICEADD_H
#define DEVICEADD_H

#include <wdf.h>

// Объявление функции EvtDeviceAdd, вызываемой при добавлении нового устройства к драйверу
EVT_WDF_DRIVER_DEVICE_ADD EvtDeviceAdd;

#endif // DEVICEADD_H
