#ifndef UTILITIES_H
#define UTILITIES_H

// Включаем необходимые заголовочные файлы
#include <wdf.h>

// Определяем перечисление для действий мыши, которые могут быть сгенерированы
typedef enum _MouseAction {
    MOVE_UP,
    MOVE_DOWN,
    MOVE_LEFT,
    MOVE_RIGHT,
    CLICK_LEFT, // Для примера, добавим действие клика левой кнопкой мыши
    CLICK_RIGHT, // Действие клика правой кнопкой мыши
    NONE // Нет действия
} MouseAction;

// Прототип функции для преобразования кода клавиши в действие мыши
MouseAction KeyToMouseAction(int keyCode);

// Прототип функции для выполнения действия мыши
void PerformMouseAction(MouseAction action);

#endif // UTILITIES_H
