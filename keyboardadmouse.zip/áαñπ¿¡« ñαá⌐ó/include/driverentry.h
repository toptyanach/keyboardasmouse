#ifndef DRIVERENTRY_H
#define DRIVERENTRY_H

#include <ntddk.h>
#include <wdf.h>

// Объявление функции DriverEntry, которая является точкой входа драйвера
extern "C" NTSTATUS DriverEntry(
    _In_ PDRIVER_OBJECT DriverObject,
    _In_ PUNICODE_STRING RegistryPath
);

// Объявление функции EvtDeviceAdd, которая вызывается при добавлении нового устройства к драйверу
EVT_WDF_DRIVER_DEVICE_ADD EvtDeviceAdd;

// Дополнительные объявления функций и структур, специфичных для вашего драйвера, могут быть добавлены здесь

#endif // DRIVERENTRY_H
