#ifndef QUEUECALLBACKS_H
#define QUEUECALLBACKS_H

#include <wdf.h>

// Объявление функции обработчика чтения для очереди ввода/вывода
EVT_WDF_IO_QUEUE_IO_READ EvtIoRead;

// Объявление функции обработчика записи для очереди ввода/вывода
EVT_WDF_IO_QUEUE_IO_WRITE EvtIoWrite;

// Функция инициализации очереди ввода/вывода может быть объявлена здесь, если требуется
NTSTATUS InitializeIoQueue(WDFDEVICE device);

#endif // QUEUECALLBACKS_H
